package HW3.Q1;

public interface Arithmetic {
    Arithmetic add(Object other);

    Arithmetic sub(Object other);

    Arithmetic mul(Object other);

    Arithmetic div(Object other);
}
