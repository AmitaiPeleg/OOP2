package HW3.Q1;

public interface Showable {
    void show();
}
