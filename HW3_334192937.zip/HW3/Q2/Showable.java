package HW3.Q2;

public interface Showable {
    void show();
}
