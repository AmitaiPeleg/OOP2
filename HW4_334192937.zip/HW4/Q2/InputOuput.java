package HW4.Q2;

import java.util.Scanner;

public interface InputOuput {
    void read();

    void write();
}
