package HW4.Q2;

public class TheSizeCanNotBeZero extends MatrixException {
    public TheSizeCanNotBeZero(){
        super("size of matrix can't be zero");
    }
}
