package HW4.Q2;
public class TheSizeCanNotBeNegativ extends MatrixException {
    public TheSizeCanNotBeNegativ() {
        super("size of matrix can't be negativ");

    }
}
