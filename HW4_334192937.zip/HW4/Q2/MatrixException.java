package HW4.Q2;

public class MatrixException extends RuntimeException {
    public MatrixException(String s){
        super(s);
    }
}
