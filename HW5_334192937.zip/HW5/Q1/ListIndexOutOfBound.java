package HW5.Q1;

public class ListIndexOutOfBound extends RuntimeException {
    public ListIndexOutOfBound() {
        super("IndexOutOfBound");
    }
}
