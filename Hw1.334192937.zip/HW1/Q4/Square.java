package Q4;
//  ריבוע יורש ממלבן
public class Square extends Rect {
    public Square(int n){
        super(n,n);
    }

}
