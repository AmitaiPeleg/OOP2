package Q4;

public class Program {
    public  static void main(String[] args) {
        Rect  r = new Rect(2,5);
        System.out.print(r.getArea()); // מודפס שטח המלבן 
       System.out.print(r.getCirc()); //מודפס היקף המלבן
       Square  s = new Square(6);
      System.out.print(s.getArea()); // מודפס שטח המלבן 
       System.out.print(s.getCirc()); //מודפס היקף המלבן
      }
      
      
      
}
