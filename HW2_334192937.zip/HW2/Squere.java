package HW2;

public class Squere extends Polygon {
    public Squere(int l) {
        super(l, l);
    }
   
}
