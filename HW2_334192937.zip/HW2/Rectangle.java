package HW2;



public class Rectangle extends Polygon {
    public Rectangle(int l, int w) {
        super(l, w);
    }
}
